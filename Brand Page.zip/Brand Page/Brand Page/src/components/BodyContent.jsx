import { Box } from '@mui/material'

import Text from './Text'
import TwoBtns from './TwoBtns'
import Footer from './Footer'

const BodyContent = () => {
  return (
    <Box>
     <Text/>
        <TwoBtns/>
        <Footer/>

    </Box>
  )
}

export default BodyContent
