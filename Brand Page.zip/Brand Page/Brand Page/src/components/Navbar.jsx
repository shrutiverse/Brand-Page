import { Avatar, Box, Button, Container } from '@mui/material'
import React from 'react'

const Navbar = () => {
  return (
    <>
     <Container>
        <Box sx={{width:'100%',display:'flex',gap:3,padding:1,}}>
            <Avatar src='../images/Nike.png' sx={{height:45, width:95}} variant='square'></Avatar>
            <Box sx={{display:'flex', alignItems:'center', gap:3, p:2, ml:35,fontWeight:'medium', fontSize:'1.5rem'}}>
                <div >Menu</div>
                <div>Location</div>
                <div>About</div>
                <div>Contact</div> 
                </Box>
                <Box sx={{ml:42}}>
                    <Button sx={{background:'red', color:'white',fontWeight:'bold',fontSize:'0.875rem'}}>
                       Login
                    </Button>
                </Box>
                </Box>

               

        
        </Container> 
    </>
  )
}

export default Navbar
