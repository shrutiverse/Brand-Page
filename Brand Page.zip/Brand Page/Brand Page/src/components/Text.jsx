import { Box, Card, Typography } from '@mui/material'

 

const Text = () => {
  return (
    <>
    <Box sx={{mt:7, p:5}}>
      <Typography variant='h2' fontWeight='900' mb={1}>YOUR FEET</Typography>
      <Typography variant='h2' fontWeight='900' mb={1}>DESERVE</Typography>
      <Typography variant='h2' fontWeight='900' mb={1}>THE BEST</Typography>
      <Typography variant='subtitle2' fontWeight='400'mt={3} sx={{opacity:0.8}}>YOUR FEET DESERVE THE BEST AND WE'RE HERE TO</Typography>
      <Typography variant='subtitle2' fontWeight='400' sx={{opacity:0.7}}>HELP YOU WITH OUR SHOES.YOUR FEET DESERVE</Typography>
      <Typography variant='subtitle2' fontWeight='400' sx={{opacity:0.7}}>THE BEST AND WE'RE HERE TO HELP YOU WITH OUR</Typography>
      <Typography variant='subtitle2' fontWeight='400' sx={{opacity:0.7}}>SHOES.</Typography>
      </Box>
    </>
  )
}

export default Text
