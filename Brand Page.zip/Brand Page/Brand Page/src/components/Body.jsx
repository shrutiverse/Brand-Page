import { Box } from "@mui/material"
import BodyContent from "./BodyContent"
import Shoe from "./Shoe"

const Body = () => {
  return (
    <Box display="flex" alignItems={"center"} gap={30}>
      <BodyContent></BodyContent>
      <Shoe></Shoe>
    </Box>
  )
}

export default Body
