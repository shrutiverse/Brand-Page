import { Avatar, Box } from '@mui/material'
import React from 'react'

const CompanyLogos = () => {
  return (
    <Box sx={{ml:1 ,mt:2,display:'flex',alignItems:'center',gap:2}}>
      <Avatar variant='square' src='../images/Flipkart.png'></Avatar>
      <Avatar variant='square' src='../images/amazon.png'></Avatar>
    </Box>
  )
}

export default CompanyLogos
