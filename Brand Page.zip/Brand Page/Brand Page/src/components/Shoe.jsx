import { Box } from "@mui/material"

const Shoe = () => {
  return (
    <>
      <Box>
        <img src="../images/shoe.png" alt="shoe image" height={500} width={400}></img>
      </Box>
    </>
  )
}

export default Shoe
