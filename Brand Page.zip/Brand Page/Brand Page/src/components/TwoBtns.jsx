import { Button ,Box} from '@mui/material'


const TwoBtns = () => {
  return (
    <>
    <Box sx={{ml:5}}>
     <Button variant='contained' sx={{background:'red'}}>Shop Now</Button> 
     <Button variant='outlined' sx={{color:'black',borderBlockColor:'black', ml:5}}>Category</Button> 
     </Box>
    </>
  )
}

export default TwoBtns
