import { Box, Typography } from "@mui/material"
import CompanyLogos from "./CompanyLogos"

const Footer = () => {
  return (
    <>
      <Box sx={{mt:2, ml:5}}>
        <Typography variant="caption" sx={{opacity:0.6}}>Also available on</Typography>
        <CompanyLogos/>
      </Box>
    </>
  )
}

export default Footer
